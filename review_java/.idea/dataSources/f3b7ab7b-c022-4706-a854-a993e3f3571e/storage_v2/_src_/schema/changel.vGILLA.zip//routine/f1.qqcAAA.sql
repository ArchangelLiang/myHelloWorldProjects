create
    definer = root@localhost function f1() returns int
begin
	declare s int default 0;
	select max(id) into s from `user`;
	return s;
end;

