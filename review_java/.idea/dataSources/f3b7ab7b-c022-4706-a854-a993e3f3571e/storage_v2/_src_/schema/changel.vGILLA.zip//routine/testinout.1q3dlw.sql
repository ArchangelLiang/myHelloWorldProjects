create
    definer = root@localhost procedure testinout(INOUT a int)
begin
select a*2 into a;
end;

