create
    definer = root@localhost procedure myp4()
begin
	insert into `user` values(null,'ddd',now(),'0','dongjing');
end;

