create
    definer = root@localhost procedure myp5()
BEGIN
INSERT INTO `user` VALUES(NULL,'eee',NOW(),'0','china');
END;

