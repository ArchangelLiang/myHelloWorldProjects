create definer = root@localhost view myv1 as
select 18 AS `age`, 'zio' AS `name`;

