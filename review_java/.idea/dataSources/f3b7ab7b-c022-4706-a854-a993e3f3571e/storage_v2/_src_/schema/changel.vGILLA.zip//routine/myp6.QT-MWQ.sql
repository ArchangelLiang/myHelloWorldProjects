create
    definer = root@localhost procedure myp6(IN name varchar(20))
SELECT * FROM `user` WHERE username = username;

