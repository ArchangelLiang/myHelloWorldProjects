create
    definer = root@localhost procedure returnphoneandname(IN id int, OUT uname varchar(20), OUT address varchar(10))
begin
	select u.username,u.address into uname,address from `user` as u where u.`id`=id;
end;

