create
    definer = root@localhost procedure myp3()
BEGIN
INSERT INTO `user` VALUES(NULL,'ccc',NOW(),'??','????');
END;

