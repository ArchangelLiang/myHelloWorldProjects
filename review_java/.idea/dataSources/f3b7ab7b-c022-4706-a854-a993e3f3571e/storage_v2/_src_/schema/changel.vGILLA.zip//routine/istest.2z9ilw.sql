create
    definer = root@localhost procedure istest(IN num int)
begin
	declare i int default 1;
	a:while i<num do
	insert into user values(null,'cxh',now(),'m','niuyue');
	if i=10 then leave a;
	end if;
	set i=i+1;
	end while a;
end;

