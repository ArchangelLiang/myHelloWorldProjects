create
    definer = root@localhost procedure cs(IN score int)
begin
	case 
	WHEN score between 90 and 100 then select 'A';
	WHEN score between 80 and 90 then select 'B';
	else select 'C';
	end case;
end;

