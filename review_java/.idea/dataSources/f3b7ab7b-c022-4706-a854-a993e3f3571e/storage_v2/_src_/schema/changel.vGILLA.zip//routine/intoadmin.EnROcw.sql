create
    definer = root@localhost procedure intoadmin(IN username varchar(20), IN passwd varchar(20))
begin
	insert into admin values(null,username,passwd);
end;

